module.exports = member => {
    let username = member.user.username;
    member.sendMessage('Sunucuya Hşgeldin **' + username + '** Eğleniceğini Düşünüyorum!');
};
