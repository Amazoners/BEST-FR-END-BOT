const Discord = require('discord.js');

exports.run = async (client, message, params, args) => {

  const yardım = new Discord.RichEmbed()
  .setColor(0x36393E)
      .setAuthor(`Amazoners`, client.user.avatarURL)
      .setDescription("[Botu sunucuya ekle](https://discordapp.com/oauth2/authorize?client_id=591518610824888353&scope=bot&permissions=2146958719) | [WebSite](https://altunkaynak.ml/)\n\n**Ping**: " + client.ping + "ms!\n\n")
      .setThumbnail(client.user.avatarURL)
      .addField(`Best Friend - Yardım`,` \n:white_small_square: | **bf!8ball**: Soru Sorarsınız! \n:white_small_square: | **bf!alkış**: Birini Alkışlarsınız! \n:white_small_square: | **bf!ara155**: Polis Çağırırsınız! [Ciddiye Almayın!] \n:white_small_square: | **bf!aşçı**: Makarnalar İle Yazı Yazarsınız! \n:white_small_square: | **bf!atatürk**:Atatürk Resmi Gösterir! \n:white_small_square: | **bf!avatar**: Avatar Fotoğarfınızı Gösterir! \n:white_small_square: | **bf!bayrak**: Bayrak Gif'i Gösterir! \n:white_small_square: | **bf!davetoluştur**: Sunucunuz İçin Davet Oluşturur! \n:white_small_square: | **bf!duyuru**: Bot Sizin İçin Kanalda Duyuru Mesajı Gönderir! \n:white_small_square: | **bf!emojiyazı**: Yazdıklarınız Emoji Yazısına Çevirir! \n:white_small_square: | **bf!gifara**: Gif Ararsınız! \n:white_small_square: | **bf!havadurumu**: Şehirinizin Hava Durumunu Görüntüler! \n:white_small_square: | **bf!herkesebendençay**: Herkese Çay Ismarlarsınız! \n:white_small_square: | **bf!hesapla**: Bir veya Daha Fazla İşlem Yaparsınız! `)
      .setFooter(`${message.author.username} tarafından istendi.`, message.author.avatarURL)
  return message.channel.sendEmbed(yardım);

};


  
exports.conf = {
    enabled: true,
    guildOnly: false,
    aliases: ['komut', 'komutlar', 'command', 'yardım', 'help', 'halp', 'y', 'h', 'commands'],
    permLevel: 0
  };
  
  exports.help = {
    name: 'yardım',
    description: 'yardım',
    usage: 'bf!yardım'
  };